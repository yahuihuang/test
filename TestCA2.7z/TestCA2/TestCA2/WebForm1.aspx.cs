﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestCA2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Thread t1 = new Thread(MyBackgroundTask);
            t1.Start();

            for (int i = 0; i < 5; i++)
            {
                Debug.Print("AAAA.");
            }
        }

        static void MyBackgroundTask()
        {
            for (int i = 0; i < 5; i++)
            {
                Debug.Print("[" + Thread.CurrentThread.ManagedThreadId + "]");

            }
        }

        static void CATest()
        {
            //int raSet = -1;
            FSVAATLLib.VAATLClass raObj = new FSVAATLLib.VAATLClass();
            /*
            raSet = raObj.FSVA_ServerAddURL("sysjust", "sysjust", strTWCA_VerifyCGI, logmsg);

            if (raSet == 0)
            {
                raObj.setRtnFields("subject,serial,cert");
                int raRtn = raObj.FSVA_STOCK_VerifySign(strSignature, strData, 0, 0, strCAID, strSrcCode, strFuncType);

                if (raRtn == 0)
                {
                    TS = DateTime.Now - startTime;
                    if (strFuncType == "S")
                        CALogInfo(string.Format("Verify Succ Dur:[{4,6}]- Url:[{3}] ID:[{0}] SignData:[{1}] Signature:[{2}] Src:[{5}] Type:[{6}] IP:[{7}] StartVerify:[{8}]", strCAID, strData, strSignature, strTWCA_VerifyCGI, (int)TS.TotalMilliseconds, strSrcCode, strFuncType, logmsg, startTime.ToString("HH:mm:ss:fff")));
                    else
                        CALogInfo(string.Format("F_Verify Succ Dur:[{4,6}]- Url:[{3}] ID:[{0}] F_SignData:[{1}] F_Signature:[{2}] Src:[{5}] Type:[{6}] IP:[{7}] StartVerify:[{8}]", strCAID, strData, strSignature, strTWCA_F_VerifyCGI, (int)TS.TotalMilliseconds, strSrcCode, strFuncType, logmsg, startTime.ToString("HH:mm:ss:fff")));
                }
                else
                {
                    TS = DateTime.Now - startTime;
                    strCode = raRtn.ToString();
                    strMessage = raObj.FSVA_GetErrorMsg(raRtn);
                    if (strFuncType == "S")
                        CALogError(string.Format("Verify Fail  Dur[{6,6}]- Url:[{5}] ID:[{2}]  ErrCode:[{0}] ErrMsg:[{1}] SignData:[{3}] Signature:[{4}] Src:[{7}] Type:[{8}] IP:[{9}] StartVerify:[{10}]", strCode, strMessage, strCAID, strData, strSignature, strTWCA_VerifyCGI, (int)TS.TotalMilliseconds, strSrcCode, strFuncType, logmsg, startTime.ToString("HH:mm:ss:fff")));
                    else
                        CALogError(string.Format("F_Verify Fail  Dur[{6,6}]- Url:[{5}] ID:[{2}]  ErrCode:[{0}] ErrMsg:[{1}] F_SignData:[{3}] F_Signature:[{4}] Src:[{7}] Type:[{8}] IP:[{9}] StartVerify:[{10}]", strCode, strMessage, strCAID, strData, strSignature, strTWCA_F_VerifyCGI, (int)TS.TotalMilliseconds, strSrcCode, strFuncType, logmsg, startTime.ToString("HH:mm:ss:fff")));
                    return false;

                }
            }*/
        }
    }
}